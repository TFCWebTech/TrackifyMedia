<?php 
class Reporter_Model extends CI_Model
{
	
    public function insert($table, $data)
    {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    public function getReporterData()
    {
        $sql="SELECT * FROM `user`; ";
        $query = $this->db->query($sql);
        return $query->result_array();
    }
    
    public function getKeywords() {
       
        $sql = "SELECT client_keywords FROM `client`; ";
        $query = $this->db->query($sql);
        
        // Check if any rows are returned
        if ($query->num_rows() > 0) {
            // Initialize an empty array to store all keywords
            $all_keywords = array();
            
            // Loop through the result set
            foreach ($query->result_array() as $row) {
                // Check if $row is an array and if 'client_keywords' key exists
                if (is_array($row) && isset($row['client_keywords'])) {
                    // Split the client_keywords by commas
                    $keywords = explode(',', $row['client_keywords']);
                    
                    // Trim each keyword to remove leading/trailing whitespace
                    $keywords = array_map('trim', $keywords);
                    
                    // Merge the keywords into the all_keywords array
                    $all_keywords = array_merge($all_keywords, $keywords);
                } else {
                    // Log or handle the case where 'client_keywords' is not found or $row is not an array
                }
            }
            
            // Remove duplicates from the combined keywords array
            $all_keywords = array_unique($all_keywords);
            
            // Return the combined and unique keywords array
            return $all_keywords;
        } else {
            // Return an empty array if no keywords are found
            return array();
        }
    }
    public function findKeywords($get_keywords ) {
        // Check if $get_keywords is already an array
        if (is_array($get_keywords)) {
            // If it's an array, simply return it
            return $get_keywords;
        }
        // Split the string by commas
        $values_array = explode(',', $get_keywords);
    
        // Trim each value to remove leading/trailing whitespace
        $values_array = array_map('trim', $values_array);
        $values_array = array_unique($values_array);
        return $values_array;
    }
  
    
    public function getAllNews() {
        $this->db->select('nd.*, na.*');
        $this->db->from('news_artical as na');
        $this->db->join('news_details as nd', 'na.news_details_id = nd.news_details_id', 'left');
        $this->db->group_by('na.news_artical_id');  // Group by news_details_id to ensure unique rows
        $result = $this->db->get()->result_array();
        
        $outArr = array();
        foreach ($result as $row) {
            $client_ids = explode(',', $row['client_id']);
            $client_names = $this->getClientName($client_ids);
            $row['client_data'] = $client_names;
            $outArr[] = $row;
        }
        return $outArr;
    }
    
    public function getClientName($client_ids) {
        $this->db->where_in('client_id', $client_ids);
        $this->db->select('client_name');
        $this->db->from('client');
        $query = $this->db->get();
        $client_names = array();
        foreach ($query->result_array() as $row) {
            $client_names[] = $row['client_name'];
        }
        return $client_names;
    }

    public function getClients() {
        // $sql="SELECT * FROM `client` WHERE `client_keywords` = $keywordData ; ";
        $sql="SELECT * FROM `client`  ; ";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function update($table, $colIdName, $id, $data)
    {
        $this->db->where($colIdName, $id);
        $result = $this->db->update($table, $data);
        return $result;
    }
}
?>