
                <!-- Begin Page Content -->
                <div class="container-fluid">
                <?php foreach($user_data as $values){?>
                    <div class="p-1">
                        <div class="row">
                            <div class="col-md-6">
                                 <div class="card p-5">
                                    <div >
                                        <h1 class="h5 text-gray text-uppercase font-weight-bold">Update Information</h1>
                                    </div>
                                    <hr>
                                   
                                    <form action ="<?php echo site_url('');?>" Method="POST" class="user">
                                            <input type="text" name="userId" class="form-control "
                                                placeholder="Enter User Id" value="<?php echo $values['user_id'];?>" hidden>
                                        <div class="form-group">
                                        <label for="" class="font-weight-bold"> Name</label>
                                            <input type="text" name="admin_name" class="form-control "
                                                placeholder="Enter User Id" value="<?php echo $values['user_name'];?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="font-weight-bold"> Email</label>
                                            <input type="text" name="admin_mail" class="form-control "
                                                placeholder="Enter User Id" value="<?php echo $values['user_email'];?>" required>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary ">
                                                UPDATE 
                                            </button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card p-5">
                                    <div >
                                        <h1 class="h5 text-gray text-uppercase font-weight-bold">Update Password</h1>
                                    </div>
                                    <hr>
                                    <form action ="{{route('admin.updatePassword')}}" Method="POST" >
                                            <input type="text" name="adminId" class="form-control "
                                                placeholder="Enter User Id" value="<?php echo $values['user_id'];?>" hidden>
                                        <div class="form-group">
                                        <label for="" class="font-weight-bold"> Password</label>
                                            <input type="password" name="password" class="form-control "
                                                placeholder="Enter Password " >
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="font-weight-bold">Confirm Password</label>
                                            <input type="password" name="password_confirmation" class="form-control "
                                                placeholder="Enter Confirm Password" >
                                               
                                        </div>
                                       
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary ">
                                                UPDATE
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <?php } ?>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


   
  