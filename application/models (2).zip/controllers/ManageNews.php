<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ManageNews extends CI_Controller {

	function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->database();
        $this->load->helper('security');
		$this->load->library('form_validation');
        $this->load->model('Reporter_Model', 'reporter', TRUE);
    }
    public function index()
    {
        $data['getAllNews'] = $this->reporter->getALlNews();
        // print_r($data);
        $data['get_clients'] = $this->reporter->getClients();
        $this->load->view('common/header');
        $this->load->view('admin/manage_news', $data);
        $this->load->view('common/footer');
    }
    public function viewNews(){
        $this->load->view('common/header');
        $this->load->view('view_news');
        $this->load->view('common/footer');
    }
 
}
?>