<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ManageNews extends CI_Controller {

	function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->database();
        $this->load->helper('security');
		$this->load->library('form_validation');
        $this->load->model('Reporter_Model', 'reporter', TRUE);
        $this->load->model('ManageNewsModel', 'manageNews', TRUE);

    }
    public function index()
    {
        $data['getAllNews'] = $this->reporter->getALlNews();
        // print_r($data);
        $data['get_clients'] = $this->reporter->getClients();
        $this->load->view('common/header');
        $this->load->view('admin/manage_news', $data);
        $this->load->view('common/footer');
    }
    public function viewNews(){
        $this->load->view('common/header');
        $this->load->view('view_news');
        $this->load->view('common/footer');
    }

    public function EditNews($news_details_id){
        $data['get_news'] = $this->manageNews->getNews($news_details_id);
        // print_r($data);
        $data['get_clients'] = $this->reporter->getClients();
        $this->load->view('common/header');
        $this->load->view('admin/edit_news', $data);
        $this->load->view('common/footer');
    }
    public function editArticle() {
        // Retrieve data from POST array
        $news_details_id = $this->input->post('news_details_id');
        $index_no = $this->input->post('index');
        $media_type = $this->input->post('media_type');
        $publication = $this->input->post('publication');
        $edition = $this->input->post('edition');
        $supplement_id = $this->input->post('SupplementId');
        $journalist_name = $this->input->post('journalist_name');
        $agency = $this->input->post('agency');
        $news_position = $this->input->post('NewsPosition');
        $news_city = $this->input->post('NewsCity');
        $category = $this->input->post('category'); 
        $headline = $this->input->post('headline');
        $summary = $this->input->post('Summary');
    
        // Initialize arrays for storing keys and clients
        $all_keys = [];
        $all_clients = [];
    
        // Loop through each index to retrieve keys and clients
        for ($i = 1; $i <= $index_no; $i++) {
            $keys = $this->input->post('getKeys' . $i);
            $clients = $this->input->post('getclient' . $i);
    
            // Merge keys and clients arrays
            if (is_array($keys)) {
                $all_keys = array_merge($all_keys, $keys);
            }
    
            if (is_array($clients)) {
                $all_clients = array_merge($all_clients, $clients);
            }
        }
    
        // Remove duplicates
        $all_keys = array_unique($all_keys);
        $all_clients = array_unique($all_clients);
    
        // Convert arrays back to strings
        $keys_string = implode(',', $all_keys);
        $clients_string = implode(',', $all_clients);  
        
        // Prepare data array for updating 'news_details' table
        $data = [
            'media_type_id' => $media_type,
            'publication_id' => $publication,
            // 'edition_id' => $edition,
            'supplement_id' => $supplement_id,
            'journalist_id' => $journalist_name,
            'agencies_id' => $agency,
            'news_position' => $news_position,
            'news_city_id' => $news_city,
            'category_id' => $category,
            'head_line' => $headline,
            'Summary' => $summary,
            'keywords' => $keys_string,
            'client_id' => $clients_string,
        ];
        //  print_r($data);
        // Update 'news_details' tabl
        $update_success = $this->reporter->update('news_details','news_details_id',$news_details_id, $data);
        
        if ($update_success) {
            // Retrieve article IDs from form
            $artical_ids = $this->input->post('index');
            // print_r($artical_ids);
            foreach ($artical_ids as $artical_id) {
                for ($i = 1; $i <= $index_no; $i++) {
                    $editor = $this->input->post('editor' . $i);
                    $page_no = $this->input->post('page_no' . $i);
    
                    // Prepare data array for updating 'news_artical' table
                    $news_article = [
                        'news_artical' => $editor,
                        'page_no' => $page_no,
                    ];
                    
                    // Update 'news_artical' table
                    $this->reporter->update('news_artical', 'news_artical_id', $news_artical_id, $news_article);
                }
            }
        }
        // // Set flash message and redirect
        $this->session->set_flashdata('success', 'Your News Is Updated');
        // redirect('ManageNews/EditNews/' . $news_details_id);
        redirect('ManageNews');
    }
}
?>