<?php 
class Reporter_Model extends CI_Model
{
	
    public function insert($table, $data)
    {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    public function getReporterData()
    {
        $sql="SELECT * FROM `user`; ";
        $query = $this->db->query($sql);
        return $query->result_array();
    }
    // public function getKeywords(){
    //     $sql = "SELECT client_keywords FROM `client`;";
    //     $query = $this->db->query($sql);
    //     return $query->result_array();
    // }
    public function getKeywords() {
        // Assuming you have a database table named 'keywords' with a column named 'client_keywords'
        $query = $this->db->get('client');

        // Check if any rows are returned
        if ($query->num_rows() > 0) {
            // Extract and return the keywords from the result set
            return $query->result_array();
        } else {
            // Return an empty array if no keywords are found
            return array();
        }
    }
    public function findKeywords($get_keywords ) {
        // Check if $get_keywords is already an array
        if (is_array($get_keywords)) {
            // If it's an array, simply return it
            return $get_keywords;
        }
        // Split the string by commas
        $values_array = explode(',', $get_keywords);
    
        // Trim each value to remove leading/trailing whitespace
        $values_array = array_map('trim', $values_array);
    
        return $values_array;
    }
  
}
?>