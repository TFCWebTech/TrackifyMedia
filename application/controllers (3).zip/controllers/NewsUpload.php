<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class NewsUpload extends CI_Controller {

	function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->database();
        $this->load->helper('security');
		$this->load->library('form_validation');
		$this->load->model('Reporter_Model', 'reporter', TRUE);
    }
    public function index()
    {
        // $data['all_staff'] = $this->staff->getStaffData();
        $this->load->view('common/header');
		$this->load->view('reporter/news_upload');
        $this->load->view('common/footer');
    }

	public function addArticle() {
		$this->form_validation->set_rules('media_type', 'media_type', 'trim|required');
		$this->form_validation->set_rules('publication', 'publication', 'trim|required');
		$this->form_validation->set_rules('edition', 'edition', 'trim|required');
		$this->form_validation->set_rules('SupplementId', 'SupplementId', 'trim|required');
		$this->form_validation->set_rules('publication_date', 'publication_date', 'trim|required');
		$this->form_validation->set_rules('journalist_name', 'journalist_name', 'trim|required');
		$this->form_validation->set_rules('author', 'author', 'trim|required');
		$this->form_validation->set_rules('agency', 'agency', 'trim|required');
		$this->form_validation->set_rules('NewsPosition', 'NewsPosition', 'trim|required');
		$this->form_validation->set_rules('NewsCity', 'NewsCity', 'trim|required');
		$this->form_validation->set_rules('category', 'category', 'trim|required');
	
		if ($this->form_validation->run() == FALSE) {
			$errors = array(
				'media_type' => form_error('media_type'),
				'publication' => form_error('publication'),
				'edition' => form_error('edition'),
				'SupplementId' => form_error('SupplementId'),
				'publication_date' => form_error('publication_date'),
				'journalist_name' => form_error('journalist_name'),
				'author' => form_error('author'),
				'agency' => form_error('agency'),
				'NewsPosition' => form_error('NewsPosition'),
				'NewsCity' => form_error('NewsCity'),
				'category' => form_error('category')
			);
			
			// Find the first non-empty error
			foreach ($errors as $key => $error) {
				if (!empty($error)) {
					$this->session->set_flashdata('error', strip_tags($error));
					echo json_encode(array('status' => 'error', 'error' => strip_tags($error), 'error_field' => $key));
					return;
				}
			}
		} else {
			$data = array(
				'media_type' => $this->input->post('media_type'),
				'publication' => $this->input->post('publication'),
				'edition' => $this->input->post('edition'),
				'supplement' => $this->input->post('SupplementId'),
				'publication_date' => $this->input->post('publication_date'),
				'journalist_name' => $this->input->post('journalist_name'),
				'author' => $this->input->post('author'),
				'agency' => $this->input->post('agency'),
				'NewsPosition' => $this->input->post('NewsPosition'),
				'news_city' => $this->input->post('NewsCity'),
				'category' => $this->input->post('category'),
				'headline' => $this->input->post('headline'),
				'summary' => $this->input->post('Summary')
			);
			
			// Process form submission (e.g., save to database)
			// Example: $this->db->insert('articles', $data);
			
			$this->session->set_flashdata('success', 'Article added successfully.');
			echo json_encode(array('status' => 'success', 'message' => 'Article added successfully.'));
		}
	}
}
?>