<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ManageClient extends CI_Controller {

	function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->database();
        $this->load->helper('security');
		$this->load->library('form_validation');
        $this->load->model('Reporter_Model', 'reporter', TRUE);
    }
    public function index()
    {
        // $data['all_staff'] = $this->staff->getStaffData();
        $this->load->view('common/header2');
        $this->load->view('superAdmin/manage_client');
        $this->load->view('common/footer');
    }
    public function addClient(){
            $client_name = $this->input->post('client_name');
	        $client_password = $this->input->post('client_password');
            $enc_pass = md5($client_password);
            $is_active = $this->input->post('is_active');
            $Keywords = $this->input->post('Keywords');
            
            // $Keyword = explode(',', $Keywords);
            //  print_r($Keyword);
	       
	}
    public function ClientInfo(){
        $this->load->view('common/header');
        $this->load->view('manage_client');
        $this->load->view('common/footer');
    }
}
?>