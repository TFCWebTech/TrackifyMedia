<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    .modal-footer{
        justify-content: flex-start !important; 
        display: block !important;
    }
</style>
<div class="container" >
    <div class="card p-3">

        <form action="#" method="post"> 
            <div class="row">
                    <div class="col-md-12 py-2">
                        <div class="text-center">
                            <h5 class="font-weight-bold text-uppercase text-color">Add Email Tempate</h5>
                        </div>
                        <hr>
                    </div>
                    <div class="col-md-12" >
                        <div class="border-with-text" data-heading="Header Information">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="header_bg_color">Header Background Color</label>
                                            <input type="text" class="form-control" name="header_bg_color" placeholder="Background Color">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="logo_url">Logo Url</label>
                                            <input type="text" class="form-control" name="logo_url" placeholder="Logo Url">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="logo_position">Logo Position</label>
                                            <select class="form-control" name="logo_position" >
                                                <option value="">Select</option>
                                                <option value="Left">Left</option>
                                                <option value="Right">Right</option>
                                                <option value="Center">Center</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="title_name">Title Name</label>
                                            <input type="text" class="form-control" name="title_name" placeholder="Title Name">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="font_color">Title Font Color</label>
                                            <input type="text" class="form-control" name="font_color" placeholder="Font Color">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="font_color">Title Font Size</label>
                                            <input type="text" class="form-control" name="font_color" placeholder="Font Color">
                                        </div>
                                       
                                    </div>
                        </div>
                    </div>

                    <div class="col-md-12 mt-3" >
                        <div class="border-with-text" data-heading="Content News">
                            <div class="row">
                                    <div class="col-md-4">
                                            <label class="px-1 font-weight-bold" for="media_type">Category </label>
                                            <select name="category"  class="form-control" accesskey="n" onkeyup="validateUserType('?text=' + this.value);">
                                            <option value="0">Select</option>
                                            <option value="111" >111</option>
                                            <option value="After Market MFCSL" >After Market MFCSL</option>
                                            <option value="After Market MFCWL" >After Market MFCWL</option>
                                            <option value="Agri Andreas Stihl" >Agri Andreas Stihl</option>
                                            <option value="Agri Honda Siel Power Products" >Agri Honda Siel Power Products</option>
                                            <option value="Agri KisanKraft" >Agri KisanKraft</option>
                                            <option value="Agriculture INDUSTRY" >Agriculture INDUSTRY</option>
                                            <option value="Airline Air France" >Airline Air France</option>
                                            <option value="Airline Air India" >Airline Air India</option>
                                            <option value="Airline AirAsia" >Airline AirAsia</option>
                                            <option value="Airline Airbus" >Airline Airbus</option>
                                            <option value="Airline Airport Infrastructure" >Airline Airport Infrastructure</option>
                                            <option value="Airline Bengaluru International Airport" >Airline Bengaluru International Airport</option>
                                            <option value="Airline BIAL Transport" >Airline BIAL Transport</option>
                                            <option value="Airline Boeing" >Airline Boeing</option>
                                            </select>
                                    </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="media_type">Publication</label>
                                            <select class="form-control" name="publication" >
                                                <option value="">Select</option>
                                                <option value="4Ps">4Ps</option>
                                                <option value="50 Fashion Brand Icons">50 Fashion Brand Icons</option>
                                                <option value="Aag">Aag</option>
                                                <option value="Abraxas Lifestyle Magazine">Abraxas Lifestyle Magazine</option>
                                                <option value="Acaai News">Acaai News</option>
                                                <option value="Accommodation Times">Accommodation Times</option>
                                                <option value="ACE">ACE</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <label class="px-1 font-weight-bold" for="media_type">Edition</label>
                                            <select class="form-control" name="edition" >
                                                <option value="">Select</option>
                                                <option value="National">National</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="author">News Summary Color</label>
                                            <input type="text" class="form-control" placeholder="Enter Summary Color" name="author">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="media_type">News Summary Font Size</label>
                                            <input type="text" class="form-control" placeholder="Enter Font Size" name="page_no">
                                        </div>

                                       
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="media_type">Headline Color </label>
                                            <input type="text" class="form-control" placeholder="Enter Headline Color" name="Headline Color">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="media_type">Headline Font </label>
                                            <select name="MediaFont" class="form-control" id="MediaFont1">
                                                            <option value="1">Select</option>
                                                            <option value="Arial">Arial</option>
                                                            <option value="Helvetica">Helvetica</option>
                                                            <option value="sans-serif">sans-serif</option>
                                                            <option value="Arial Black">Arial Black</option>
                                                            <option value="Times New Roman">Times New Roman</option>
                                                            <option value="Gadget,sans-serif">Gadget,sans-serif</option>
                                                            <option value="Comic Sans MS">Comic Sans MS</option>
                                                            <option value="cursive">cursive</option>
                                                            <option value="Courier New">Courier New</option>
                                                            <option value="Courier">Courier</option>
                                                            <option value="monospace">monospace</option>
                                                            <option value="Georgia">Georgia</option>
                                                            <option value="serif">serif</option>
                                                            <option value="Impact">Impact</option>
                                                            <option value="Charcoal">Charcoal</option>
                                                            <option value="Lucida Console">Lucida Console</option>
                                                            <option value="Monaco">Monaco</option>
                                                            <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                                                            <option value="Lucida Grande">Lucida Grande</option>
                                                            <option value="Tahoma">Tahoma</option>
                                                            <option value="Geneva">Geneva</option>
                                                            <option value="Verdana">Verdana</option>
                                                        </select>
                                        </div>
                                    
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="media_type">Headline Font Size </label>
                                            <input type="text" class="form-control" placeholder="Enter Font Size " name="Headline Color">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="media_type">Media Details </label>
                                            <select name="category"  class="form-control" accesskey="n" onkeyup="validateUserType('?text=' + this.value);">
                                            <option value="0">Select</option>
                                            <option value="Yes" >Yes</option>
                                            <option value="No" >No</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="media_type">Media Color </label>
                                            <input type="text" class="form-control" placeholder="Enter Media Color" name="Headline Color">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="Time">Media Font  </label>
                                            <select name="MediaFont" class="form-control" id="MediaFont1">
                                                            <option value="1">Select</option>
                                                            <option value="Arial">Arial</option>
                                                            <option value="Helvetica">Helvetica</option>
                                                            <option value="sans-serif">sans-serif</option>
                                                            <option value="Arial Black">Arial Black</option>
                                                            <option value="Times New Roman">Times New Roman</option>
                                                            <option value="Gadget,sans-serif">Gadget,sans-serif</option>
                                                            <option value="Comic Sans MS">Comic Sans MS</option>
                                                            <option value="cursive">cursive</option>
                                                            <option value="Courier New">Courier New</option>
                                                            <option value="Courier">Courier</option>
                                                            <option value="monospace">monospace</option>
                                                            <option value="Georgia">Georgia</option>
                                                            <option value="serif">serif</option>
                                                            <option value="Impact">Impact</option>
                                                            <option value="Charcoal">Charcoal</option>
                                                            <option value="Lucida Console">Lucida Console</option>
                                                            <option value="Monaco">Monaco</option>
                                                            <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                                                            <option value="Lucida Grande">Lucida Grande</option>
                                                            <option value="Tahoma">Tahoma</option>
                                                            <option value="Geneva">Geneva</option>
                                                            <option value="Verdana">Verdana</option>
                                                        </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="Duration">Media Font Size</label>
                                            <input type="text" class="form-control" placeholder="Enter Font Size" name="Font Size">
                                        </div>
                                    

                                        <div class="col-md-4">
                                            <label class="px-1 font-weight-bold" for="media_type">Context  </label>
                                            <select name="category"  class="form-control" accesskey="n" onkeyup="validateUserType('?text=' + this.value);">
                                            <option value="0">Select</option>
                                            <option value="Yes" >Yes</option>
                                            <option value="No" >No</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="Time">Context Font</label>
                                            <select name="MediaFont" class="form-control" id="MediaFont1">
                                                            <option value="1">Select</option>
                                                            <option value="Arial">Arial</option>
                                                            <option value="Helvetica">Helvetica</option>
                                                            <option value="sans-serif">sans-serif</option>
                                                            <option value="Arial Black">Arial Black</option>
                                                            <option value="Times New Roman">Times New Roman</option>
                                                            <option value="Gadget,sans-serif">Gadget,sans-serif</option>
                                                            <option value="Comic Sans MS">Comic Sans MS</option>
                                                            <option value="cursive">cursive</option>
                                                            <option value="Courier New">Courier New</option>
                                                            <option value="Courier">Courier</option>
                                                            <option value="monospace">monospace</option>
                                                            <option value="Georgia">Georgia</option>
                                                            <option value="serif">serif</option>
                                                            <option value="Impact">Impact</option>
                                                            <option value="Charcoal">Charcoal</option>
                                                            <option value="Lucida Console">Lucida Console</option>
                                                            <option value="Monaco">Monaco</option>
                                                            <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                                                            <option value="Lucida Grande">Lucida Grande</option>
                                                            <option value="Tahoma">Tahoma</option>
                                                            <option value="Geneva">Geneva</option>
                                                            <option value="Verdana">Verdana</option>
                                                        </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="Duration">Context Font Size</label>
                                            <input type="text" class="form-control" placeholder="Context Font Size" name="Font Size">
                                        </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 mt-3">
                        <div class="border-with-text" data-heading="Footer Information">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="header_bg_color">Footer Background Color</label>
                                            <input type="text" class="form-control" name="header_bg_color" placeholder="Background Color">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="logo_url">Logo Url</label>
                                            <input type="text" class="form-control" name="logo_url" placeholder="Logo Url">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="logo_position">Logo Position</label>
                                            <select class="form-control" name="logo_position" >
                                                <option value="">Select</option>
                                                <option value="Left">Left</option>
                                                <option value="Right">Right</option>
                                                <option value="Center">Center</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="title_name">Title Name</label>
                                            <input type="text" class="form-control" name="title_name" placeholder="Title Name">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="font_color">Title Font Color</label>
                                            <input type="text" class="form-control" name="font_color" placeholder="Font Color">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="px-1 font-weight-bold" for="font_color">Title Font Size</label>
                                            <input type="text" class="form-control" name="font_color" placeholder="Font Color">
                                        </div>
                                       
                                    </div>
                         </div>
                    </div>

                    <div class="col-md-12 text-right px-4 py-2">
                        <a  class="btn btn-success" data-toggle="modal" data-target="#tatamoters">Preview</a>
                        <button  class="btn btn-primary">Save Page</button>
                    </div>
        </form>

    </div>
</div>          
<script>
    // Get the current time
    const currentTime = new Date();
    
    // Format the current time as HH:MM:SS
    const formattedTime = currentTime.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });

    // Set the formatted time in the input field
    document.getElementById("current_time").value = formattedTime;
</script>
<!-- this div is for footer --->
</div>

<script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>

 <script type="text/javascript">
   CKEDITOR.replace( 'editor1' );
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
   
   $(document).ready(function() {
    $('#image_upload').on('change', function() {
        const file = this.files[0];
        const formData = new FormData();
        formData.append('image_upload', file); // Correct key name

        // Get CSRF token from meta tag
        const csrfToken = $('meta[name="csrf-token"]').attr('content');

        // Send AJAX request to store the image
        $.ajax({
            type: 'POST',
            url: "<?php echo site_url('Reporter/saveArticalImage')?>",
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': csrfToken // Include CSRF token in headers
            },
            success: function(response) {
                var jsonResponse = JSON.parse(response);
                // Get the image URI from the parsed response
                var imageUri = jsonResponse.image_uri.replace(/\\/g, ''); // Remove backslashes
                // var imageUri = response;
                console.log("Image URI:", imageUri);
                imageToText(imageUri);
            }
        });
    });
});
// imageToText(imageUri);
function imageToText(imageUri) {
    $.ajax({
        url: 'https://vision.googleapis.com/v1/images:annotate?key=AIzaSyBYb7FLN__svPKZUbaOeoV4kxZrNoxehLw', 
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            "requests": [
                {
                    "image": {
                        "source": {
                            "imageUri": imageUri
                        }
                    },
                    "features": [
                        {
                            "type": "TEXT_DETECTION"
                        }
                    ]
                }
            ]
        }),
        success: function(response) {
            // Handle success
            var description = response.responses[0].textAnnotations[0].description;
            console.log(description);

            // Get the CKEditor instance by ID
            var editor = CKEDITOR.instances.text_convert;

            if (editor) {
                // Set the content of the CKEditor instance
                editor.setData(description);
            } else {
                console.error('CKEditor instance not found.');
            }
        },
        error: function(xhr, status, error) {
            // Handle error
            console.error(error);
        }
    });
}
</script>

<!-- The Modal -->
<div class="modal" id="tatamoters">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="background-color:#f5f9ff;">

      <!-- Modal Header -->
      <div class="modal-header " style="background-color:#0a0a5f;">
        <h4 class="modal-title text-light">TATA Moters</h4>
        <!-- Correct close button for Bootstrap 4 -->
        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <!-- Modal Body -->
      <div class="modal-body">
            <h4 class="text-primary">Wind energy surpasses gas in electricity generation</h4>
            <p>In a first for the European Union (EU), wind energy has surpassed gas, with more of it being used to generate energy in 2023.
               In a win for the renewable energy sector, wind energy produced 18 percent of the electricity generated last year, compared with 17% for gas. Combined with solar energy, the two renewable sources created 27% of the EU’s electricity, which is the first time it has ever generated more than a quarter. This is an increase from 2022, where wind energy generated 13% of all electricity. “The EU’s power sector is in the middle of a monumental shift,” says Sarah Brown, Ember’s Europe programme director. “Fossil fuels are playing a smaller role than ever as a system with wind and solar as its backbone comes into view.”
               This is great news for the EU, as they battle to cut their greenhouse gas usage by 90% by 2040.
                Some countries are leading the way in renewable wind power. With 58% of its electricity coming from turbines, Denmark’s wind production exceeds any other OEDC (Organisation for Economic Co-operation and Development) country per capita.</p>
      </div>
        <div class="modal-footer text-start" style="background-color:#0a0a5f;">
             <h6 class="text-white">SOCIAL MEDIA</h6> 
             <div >
                <i class="fa fa-facebook text-white"></i> &nbsp;
                <i class="fa fa-instagram text-white"></i> &nbsp;
                <i class="fa fa-linkedin text-white"></i> &nbsp;
                <i class="fa fa-youtube-play text-white"></i>
             </div>
        </div>
    </div>
  </div>
</div>