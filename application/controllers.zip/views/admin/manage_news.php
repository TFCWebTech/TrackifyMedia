<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    .modal-footer{
        justify-content: flex-start !important; 
        display: block !important;
    }
</style>
<div class="container">
    <!-- <div class="d-flex justify-content-end">
            <div class="d-flex text-right p-1 ">
                        <input type="date" class="form-control m-1" placeholder="Enter Headline">
                        <button class="btn btn-primary m-1">Search</button>
            </div>
        </div> -->
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Wind energy surpasses gas in electricity generation </h6>
                    </div>
                    <div class="card-body">
                    <img src="<?php echo base_url('assets/img/newspaper.jpg');?>" style="width:100%;" alt="">
                            <p>In a win for the renewable energy sector, wind energy produced 18 percent of the electricity generated last year... </p>
                            <p> <span class="text-primary">Keywords Finds : </span>  energy , electricity generation , solar energy</p>   
                            <!-- <a target="_blank" rel="nofollow" href="">Preview</a> -->
                            <p> <span class="text-primary">Clients Finds : </span> &nbsp;Tata Motors <i class="fa fa-eye cursor " data-toggle="modal" data-target="#tatamoters"></i> &nbsp;, Hyundai <i class="fa fa-eye"></i> , &nbsp;Mahindra <i class="fa fa-eye"></i> </p>
                            <div class="text-right">
                            <button class="btn btn-primary"> Send mail </button>
                              </div>  
                        </div>
                    </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Solar-powered electric car to be released this year</h6>
                    </div>
                    <div class="card-body">
                            <img src="<?php echo base_url('assets/img/newspaper.jpg');?>" style="width:100%;" alt="">
                            <p id="dynamicContent">A new electric car is being released this year with an added feature; it can run on solar power.
                                Dutch start-up Lightyear have created the first ‘production ready’ electric car, the Lightyear 0, that can charge itself using the power of the sun. In fact, the company claim that the car can go for months without being charged, thanks to its curved solar panels on its roof and a 60kWh battery pack.</p>
                            <p> <span class="text-primary">Keywords Finds : </span> electric car  , solar panels , solar power </p>   
                          
                            <p> <span class="text-primary">Clients Finds : </span> &nbsp;Tata Motors <i class="fa fa-eye"></i>, &nbsp;Hyundai <i class="fa fa-eye"></i> , &nbsp;Mahindra <i class="fa fa-eye"></i> </p>
                              <div class="text-right">
                                <button class="btn btn-primary"> Send mail </button>
                              </div>  
                        </div>
                    </div>
            </div>
        </div>
</div>

<!-- The Modal -->
<div class="modal" id="tatamoters">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="background-color:#f5f9ff;">

      <!-- Modal Header -->
      <div class="modal-header " style="background-color:#0a0a5f;">
        <h4 class="modal-title text-light">TATA Moters</h4>
        <!-- Correct close button for Bootstrap 4 -->
        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <!-- Modal Body -->
      <div class="modal-body">
            <h4 class="text-primary">Wind energy surpasses gas in electricity generation</h4>
            <p>In a first for the European Union (EU), wind energy has surpassed gas, with more of it being used to generate energy in 2023.
               In a win for the renewable energy sector, wind energy produced 18 percent of the electricity generated last year, compared with 17% for gas. Combined with solar energy, the two renewable sources created 27% of the EU’s electricity, which is the first time it has ever generated more than a quarter. This is an increase from 2022, where wind energy generated 13% of all electricity. “The EU’s power sector is in the middle of a monumental shift,” says Sarah Brown, Ember’s Europe programme director. “Fossil fuels are playing a smaller role than ever as a system with wind and solar as its backbone comes into view.”
               This is great news for the EU, as they battle to cut their greenhouse gas usage by 90% by 2040.
                Some countries are leading the way in renewable wind power. With 58% of its electricity coming from turbines, Denmark’s wind production exceeds any other OEDC (Organisation for Economic Co-operation and Development) country per capita.</p>
      </div>
        <div class="modal-footer text-start" style="background-color:#0a0a5f;">
             <h6 class="text-white">SOCIAL MEDIA</h6> 
             <div >
                <i class="fa fa-facebook text-white"></i> &nbsp;
                <i class="fa fa-instagram text-white"></i> &nbsp;
                <i class="fa fa-linkedin text-white"></i> &nbsp;
                <i class="fa fa-youtube-play text-white"></i>
             </div>
        </div>
    </div>
  </div>
</div>

<script>
// Get the text node within the td element
const td = document.getElementById("dynamicContent");
const textNode = td.childNodes[0];

// Split the content into an array of words
const words = textNode.textContent.trim().split(" ");

// Join the first seven words with a space
const truncatedText = words.slice(0, 30).join(" ");

// Add ellipsis
const newText = truncatedText + "...";

// Update the content of the text node
textNode.textContent = newText;
</script>

</div>

            <!-- End of Main Content -->    