<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    .container{
        border: 1px solid #c3c3c3;
    }
.table-wrapper {
    overflow-x: auto;
}

table {
    border-collapse: collapse;
    width: 100%;
}

td {
    padding: 5px;
}

th {
    text-align: center;
    padding: 5px;
}

.table-wrapper > table,
.table-wrapper > table td,
.table-wrapper > table th {
    border: 1px solid #c3c3c3;
}
.header_contert {
            display: flex;
            justify-content: space-between;
        }

        @media (max-width: 725px) {
            .header_contert {
                display: block;
                text-align: center;
            }
        }
</style>
</head>

<div class="container">
    <div class="card" style="padding:10px;">
        <div class="row">
            <div class="col-md-12">
                <table width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="left"> <img src="<?php echo base_url('assets/img/logo.png');?>" alt="logo" style="width:100px;"> <br>
                        <a href="" style="font-size:12px;">powered by trackify media</a></td>
                        <td align="center">
                        <h5 class="w-100 font-size:18px;"><?php echo $client_name; ?> <br>
                            <span style="font-size:12px; display:block;">Saturday, May 25, 2024 <br>
                             <span style="font-size:12px;">  0 News / <a href=""> view consolidated</a></span>
                            </span>
                        </h5>
                        </td>
                        <td align="right"> <img src="<?php echo base_url('assets/img/logo.png');?>" alt="logo" style="width:100px;"></td>
                    </tr>
                </table>
              
                <hr>
            </div>
            <div class="table-wrapper">
                <table>
                    <tr>
                        <th>Quick Links</th>
                        <th>News That Matters</th>
                        <th>Access Other Services</th>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Login</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>User Guide</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Edit | Pdf | Word</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Customerservice@bluebytes.info</td>
                    </tr>
                </table>
            </div>
            <?php if (!empty($news_details)) { ?>
                <?php foreach ($news_details as $news) { ?>
                    <h2 style="margin-top:20px; padding-left: 5px;"><a href>  <?php echo $news['head_line'];?></a></h2>
                    <?php if (!empty($news['news_article_data'])) { ?>
                        <?php foreach ($news['news_article_data'] as $articleGroup) { ?>
                            <?php if (!empty($articleGroup['articles'])) { ?>
                                <?php foreach ($articleGroup['articles'] as $articleData) { ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="news my-2">
                                            <p>
                                                <?php echo isset($articleData['news_artical']) ? $articleData['news_artical'] : 'No article available'; ?>
                                            </p>
                                        </div>
                                        <hr>
                                    </div>
                                <?php } ?>
                            <?php } else { ?>
                                <div class="col-md-12 mt-3">
                                    <p>No article data available.</p>
                                    <hr>
                                </div>
                            <?php } ?>
                        <?php } ?>
                    <?php } else { ?>
                        <div class="col-md-12 mt-3">
                            <p>No article data available.</p>
                            <hr>
                        </div>
                    <?php } ?>
                <?php } ?>
            <?php } else { ?>
                <p>No news available.</p>
            <?php } ?>
            <div class="col-md-12 mt-1">
                <div class="d-flex justify-content-between mx-2">
                    <div class="logo">
                        <!-- <img src="<?php echo base_url('assets/img/logo.png');?>" alt="logo" style="width:100px;"> <br> -->
                        <p>This is an auto generated email – please do not reply to this email id</p>
                    </div>
                    <div class="header d-flex align-items-center text-center">
                        <!-- <h5 class="w-100">London Heathrow Airport <br>
                            <span style="font-size:12px; display:block;">Saturday, May 25, 2024 <br>
                             <span>  0 News / <a href=""> view consolidated</a></span>
                            </span>
                        </h5> -->
                    </div>
                    <div class="header">
                        <!-- <img src="<?php echo base_url('assets/img/logo.png');?>" alt="logo" style="width:100px;"> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
