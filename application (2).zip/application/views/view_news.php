

<div class="container">
    
   
    <div class="card p-3">
        <div class="row">
            <div class="col-md-12">
                        <div class="text-center">
                            <h5 class="font-weight-bold text-uppercase text-color">News</h5>
                        </div>
            </div>

            <div class="col-md-12" >
                        <div class="border-with-text" data-heading="Sub Editor Upload">
                                    <div class="row">
                                    <div class="col-md-12">
                                            <label class="px-1 font-weight-bold" for="media_type">Head Line</label>
                                            <textarea class="form-control" name="" id="" cols="30" rows="10"></textarea>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="px-1 font-weight-bold" for="media_type">Summary</label>
                                            <textarea class="form-control" name="" id="" cols="30" rows="10"></textarea>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="px-1 font-weight-bold" for="media_type">News </label>
                                            <textarea class="form-control" name="" id="" cols="30" rows="10"> </textarea>
                                        </div>
                                        <div class="col-md-12 text-right mt-2">
                                            <button class="btn btn-primary">Save</button>
                                        </div>
                                    </div>
                        </div>
            </div>
        </div>

    </div>
</div>

<!-- this div is for footer --->
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
        $(document).ready(function() {
            // Toggle button click event
            $('#toggleButton').click(function() {
                // Toggle visibility of the section
                $('#headlineSearchSection').toggle();
            });
        });
</script>