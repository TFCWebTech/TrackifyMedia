<?php 
class News_data_Model extends CI_Model
{
  
        public function getPublicationTypeData(){
        $this->db->select('gidPublicationType, PublicationType');
        $this->db->from('publicationtype');
        return $this->db->get()->result_array();
        }

        public function getNewsCityData(){
        $this->db->select('*');
        $this->db->from('newscity');
        return $this->db->get()->result_array();
        }

        public function getReportData($client_id, $from_date = null, $to_date = null, $publication_type, $Cities) {
            // Ensure $client_id is an array
            if (!is_array($client_id)) {
                $client_id = array($client_id);
            }
        
            // Convert $client_id array to a comma-separated string of integers
            $client_ids = implode(',', array_map('intval', $client_id));
        
            // Begin building the query
            $this->db->select('*');  
            $this->db->from('news_details as nd'); // Use alias for clarity
            $this->db->join('mediatype as mt', 'nd.media_type_id = mt.gidMediaOutlet', 'left');
            $this->db->join('mediaoutlet as mo', 'nd.publication_id = mo.gidMediaType', 'left');
            $this->db->join('edition as e', 'nd.gidEdition = e.gidEdition', 'left');
            $this->db->join('supplements as sp', 'nd.supplement_id = s.gidSupplement', 'left');
            $this->db->join('newscity as nc', 'nd.news_city_id = nc.gidNewscity', 'left');
          
            // Build client_id conditions
            $client_id_conditions = array_map(function($id) {
                return "FIND_IN_SET('$id', nd.client_id) > 0";
            }, $client_id);
        
            // Join the conditions with OR to match any client_id
            $this->db->where('('.implode(' OR ', $client_id_conditions).')');
        
            // Optionally add publication_type condition if provided
            if (!empty($publication_type) && $publication_type !== 'Select') {
                $this->db->where('nd.publication_type', $publication_type);
            }
        
            // Optionally add Cities condition if provided
            // if (!empty($Cities) && $Cities !== 'Select') {
            //     $this->db->where('nd.city_id', $Cities);
            // }
        
            // Optionally add date filtering if $from_date and $to_date are provided
            if ($from_date !== null && $to_date !== null) {
                $this->db->where('nd.create_at >=', $from_date);
                $this->db->where('nd.create_at <=', $to_date);
            }
        
            // Execute the query and return the result
            $query = $this->db->get();
        
            // Debugging line: print the SQL query for inspection
            // echo $this->db->last_query();
        
            return $query->result_array();
        }
        
        
}
?>