<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>

<style>
table.dataTable th,
table.dataTable td {
  white-space: nowrap;
}
.dataTables_wrapper .dataTables_filter input, .dataTables_wrapper .dataTables_length select{
padding: 2px !important;
margin-bottom: 5px !important;
}
.dataTables_wrapper .dataTables_paginate .paginate_button{
    padding: .2em .3em !important;
}
.form-group {
    margin-bottom: 0rem !important;
}
.modal-body{
    padding: 0rem .5rem .5rem .5rem  !important;
}
/* @media (min-width: 768px) { */
        .table-container-responsive{
            overflow-x: auto;
        }
    /* } */
</style>
<div class="container">
    
        <!-- <div class="card p-3 my-2"  id="headlineSearchSection" > -->
            <form >
            <div class="row">
                <div class="col-md-12 card p-3">
                    <div class="row ">
                        <div class="col-md-6">
                            <h6 class="text-primary font-weight-bold p-2">
                                Reports
                            </h6>
                        </div>
                        <div class="col-md-6 text-right d-flex">
                            <label class="px-2 font-weight-bold" >Date  </label>
                            <input type="date" name="from_date" id="from_date" class="form-control px-2 mx-1"> 
                            <input type="date" name="to_date" id="to_date" class="form-control px-2 mx-1"> 
                        </div>
                    </div>
                    <div class="border-with-text" data-heading="Filter Options">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="px-1 font-weight-bold" for="publication_type">Publication Type</label>
                                <select class="form-control" name="publication_type" id="publication_type">
                                <option disbled>Select</option>
                                        <?php foreach($publication_type as $values){?>
                                        <option value="<?php echo $values['gidPublicationType'];?>"> <?php echo $values['PublicationType'];?></option>
                                        <?php }?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="px-1 font-weight-bold" for="Cities">Cities</label>
                                <select class="form-control" name="Cities" id="Cities">
                                <option disbled>Select</option>
                                        <?php foreach($news_city as $values){?>
                                        <option value="<?php echo $values['gidNewscity'];?>"> <?php echo $values['CityName'];?></option>
                                        <?php }?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="px-1 font-weight-bold" for="eDossier ">eDossier </label> <br>
                                <a class="bth">PDF</a> | <a onclick="downloadWord()" class="bth">WORD</a>
                            </div>
                    
                            <div class="col-md-2 mt-3 pt-2">
                                <button class="btn btn-primary">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </form>

        </div>
</div>

<script>
function downloadWord() {
    var from_date = document.getElementById('from_date').value;
    var to_date = document.getElementById('to_date').value;
    var publication_type = document.getElementById('publication_type').value;
    var Cities = document.getElementById('Cities').value;

    console.log('From Date:', from_date); // Debugging line
    console.log('To Date:', to_date); // Debugging line
    console.log('Publication Type:', publication_type); // Debugging line
    console.log('Cities:', Cities); // Debugging line

    $.ajax({
        type: "POST",
        url: "<?php echo site_url('Report/exportWord'); ?>",
        dataType: 'json', // Expecting JSON response
        data: {
            from_date: from_date,
            to_date: to_date,
            publication_type: publication_type,
            Cities: Cities,
        },
        success: function(response) {
            console.log("Update successful", response);

            // Construct CSV content from JSON data
            var csvContent = "data:text/csv;charset=utf-8,";
            csvContent += "News Date, Media Type,Publication,Edition,Supplement,Journalist,News City\n";

            response.forEach(function(row) {
                csvContent += row.create_at	 + "," +
                              row.head_line + "," +
                              row.head_line + "," +
                              row.MediaType + "," +
                              row.PublicationType + "," +
                              row.Edition + "," +
                              row.Supplement + "," +
                              row.Journalist + "," +
                              row.CityName + "\n";
            });

            // Create a hidden link element to trigger the download
            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "data.csv");
            document.body.appendChild(link); // Required for FF
            link.click();

            // Remove the link from the body
            document.body.removeChild(link);
        },
        error: function(xhr, status, error) {
            console.error("Error:", error);
        }
    });
}
</script>

<script>
    $('table').DataTable();
</script>

